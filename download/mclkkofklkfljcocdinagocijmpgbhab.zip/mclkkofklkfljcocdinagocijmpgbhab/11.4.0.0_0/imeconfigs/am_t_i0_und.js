(function(){/*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';var d=function(a){if(c!==c)throw Error("Bad secret");this.g=a},e=function(a){console.warn("A URL with content '"+a+"' was sanitized away.")};var c={};d.prototype.toString=function(){return this.g};new d("about:blank");new d("about:invalid#zClosurez");var f=[];f.indexOf(e)===-1&&f.push(e);google.elements.ime.loadConfig("am-t-i0-und",{0:0,1:2,2:!0,3:!0,4:!1,5:!1,6:!1,7:!1,8:!1,9:!0,10:!1,28:!1,11:!0,12:!0,13:50,14:6,15:1,16:null,19:function(a,b){a="";b=="."?a="\u1362":b==","&&(a="\u1363");b={back:0};return(b.text=a)?b:null},22:/[a-z`]/i,27:/[^a-z`\d\u1200-\u1357]/i});}).call(this);
