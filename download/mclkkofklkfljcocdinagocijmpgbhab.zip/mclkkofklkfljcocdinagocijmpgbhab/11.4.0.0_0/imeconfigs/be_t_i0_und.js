(function(){/*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';var c=function(a){if(b!==b)throw Error("Bad secret");this.A=a},d=function(a){console.warn("A URL with content '"+a+"' was sanitized away.")};var b={};c.prototype.toString=function(){return this.A};new c("about:blank");new c("about:invalid#zClosurez");var e=[];e.indexOf(d)===-1&&e.push(d);google.elements.ime.loadConfig("be-t-i0-und",{0:0,1:2,2:!0,3:!0,4:!1,5:!0,6:!1,7:!1,8:!1,9:!0,10:!1,28:!1,11:!0,12:!0,13:50,14:6,15:1,16:{"'":["\u044c"],a:["\u0430"],b:["\u0431"],c:["\u0446"],ch:["\u0445","\u0447"],cz:["\u0447"],d:["\u0434"],dz:["\u0434\u0436","\u0434\u0437"],dzh:["\u0434\u0436"],e:["\u0435","\u044d","\u0451"],f:["\u0444"],g:["\u0433","\u0491"],h:["\u0433","\u0445"],i:["\u0439","\u0456"],ia:["\u044f"],ie:["\u0435"],io:["\u0451"],iu:["\u044e"],j:["\u0439"],ja:["\u044f"],je:["\u0435",
"\u044d"],jo:["\u0451"],ju:["\u044e"],k:["\u043a"],kh:["\u0445"],l:["\u043b"],m:["\u043c"],n:["\u043d"],o:["\u043e","\u0451"],p:["\u043f"],r:["\u0440"],s:["\u0441"],sh:["\u0448"],sia:["\u0441\u044f"],sz:["\u0448"],t:["\u0442"],ts:["\u0446"],u:["\u0443","\u045e"],v:["\u0432"],w:["\u045e"],x:["\u043a\u0441","\u0445"],y:["\u0439","\u044b"],ya:["\u044f"],ye:["\u0435"],yo:["\u0451"],yu:["\u044e"],z:["\u0437"],zh:["\u0436"]},22:/[a-z'\[\]\\]/i,27:/[^a-z'\[\]\\\u0401-\u045e]/i});}).call(this);
