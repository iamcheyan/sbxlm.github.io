(function(){/*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';var e=function(a){if(d!==d)throw Error("Bad secret");this.g=a},f=function(a){console.warn("A URL with content '"+a+"' was sanitized away.")};var d={};e.prototype.toString=function(){return this.g};new e("about:blank");new e("about:invalid#zClosurez");var g=[];g.indexOf(f)===-1&&g.push(f);google.elements.ime.loadConfig("ar-t-i0-und",function(){var a={",":"\u060c",";":"\u061b","?":"\u061f"};return{0:0,1:0,2:!0,3:!0,4:!1,5:!1,6:!1,7:!1,8:!1,9:!0,10:!1,28:!0,11:!0,12:!0,13:50,14:6,15:1,16:null,19:function(b,c){b={back:0};return c in a?(b.text=a[c],b):null},21:function(b,c){return(b+c).match(/^([aei]l) /i)?{back:0,text:"-"}:null},22:/[a-z0-9`_\-' ]/i,27:/[^a-z0-9`_\-'\u0600-\u06FF]/i}}());}).call(this);
