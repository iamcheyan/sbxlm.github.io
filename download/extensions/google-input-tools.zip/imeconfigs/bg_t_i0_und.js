(function(){/*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';var c=function(a){if(b!==b)throw Error("Bad secret");this.A=a},d=function(a){console.warn("A URL with content '"+a+"' was sanitized away.")};var b={};c.prototype.toString=function(){return this.A};new c("about:blank");new c("about:invalid#zClosurez");var e=[];e.indexOf(d)===-1&&e.push(d);google.elements.ime.loadConfig("bg-t-i0-und",{0:0,1:2,2:!0,3:!0,4:!1,5:!1,6:!1,7:!1,8:!1,9:!0,10:!1,28:!1,11:!0,12:!0,13:50,14:6,15:1,16:{"'":["\u044a","\u044c"],a:["\u0430","\u044a"],b:["\u0431"],c:["\u0446"],ch:["\u0447"],cz:["\u0447"],d:["\u0434"],e:["\u0435"],f:["\u0444"],g:["\u0433"],h:["\u0445"],i:["\u0438","\u0439"],ia:["\u044f"],iu:["\u044e"],j:["\u0439","\u044c"],ja:["\u044f"],ju:["\u044e"],k:["\u043a"],kh:["\u0445"],l:["\u043b"],m:["\u043c"],n:["\u043d"],o:["\u043e"],ou:["\u0443"],p:["\u043f"],
r:["\u0440"],s:["\u0441"],sh:["\u0448"],sht:["\u0449"],sia:["\u0441\u044f"],sz:["\u0448"],t:["\u0442"],ts:["\u0446"],tz:["\u0446"],u:["\u0443","\u044a"],v:["\u0432"],x:["\u043a\u0441"],y:["\u0439","\u044c"],ya:["\u044f"],yu:["\u044e"],z:["\u0437"],zh:["\u0436"]},22:/[a-z'\[\]\\`]/i,27:/[^a-z'\[\]\\`\u0400-\u04ff]/i});}).call(this);
